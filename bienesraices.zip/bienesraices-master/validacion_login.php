<?php
// Incluimos la BD para poder usar sus variables
include 'conexion.php';

// Iniciamos una sesión en la app
session_start();

// Cambiamos las variables del método POST a variables de sesión
$_SESSION['username'] = $_POST['username'];
$_SESSION['password'] = $_POST['password'];

// Evitamos problemas de seguridad usando sentencias preparadas
$consulta = "SELECT * FROM usuarios WHERE usuario = ? AND contraseña = ?";
$stmt = mysqli_prepare($conexion, $consulta);
mysqli_stmt_bind_param($stmt, "ss", $_SESSION['username'], $_SESSION['password']);
mysqli_stmt_execute($stmt);

$usuario = mysqli_stmt_get_result($stmt);

// Comprobamos si se encontró al usuario
if ($filas = mysqli_fetch_array($usuario)) {
    $_SESSION['usuario'] = $filas['usuario'];
    
    if ($filas['id_rol'] == 1) {
        // Entrada en modo administrador
        header("location: menu_admin.php");
    } else if ($filas['id_rol'] == 2) {
        // Entrada en modo vendedor
        header("location: menu_vendedor.php");
    } } else {
        // Usuario no encontrado en la base de datos
        header("location: login.php?error=usuario_no_registrado");
        session_destroy();
    }

// Cerramos la conexión y liberamos los resultados
mysqli_stmt_close($stmt);
mysqli_close($conexion);
?>
