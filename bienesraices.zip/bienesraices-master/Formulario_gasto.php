<?php

include 'php/conexion_be.php';
    
session_start();

if(!isset($_SESSION['usuario'])){
    echo '
        <script>
             alert("Por favor debes iniciar sesión");
        window.location = "login.php";
        </script>
   ';
   session_destroy();
   die();
}

$persona = $_SESSION['usuario'];

$usuario = mysqli_query($conexion, "SELECT id_usuario, Usuario, Correo FROM usuario WHERE Usuario='$persona'");

$data = mysqli_fetch_array($usuario);

  $idusu = $data['id_usuario'];
  $usu= $data['Usuario'];
  $correo = $data['Correo'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<title></title> 
    <meta http-equiv="X-UA-Compatible" content="width=device-width, user-scalable=yes, initial-scale=1.0, maximum-scale=3.0, minimum-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
       <link rel="stylesheet" href="style.css">


</head>
<body>
    <form action="php/gastos.php" method="POST" class="formulario">
    <input type="hidden" name="usuario" value="<?php echo $idusu;?>">
        <h1>Datos de gasto</h1>
        <div class="contenedor">

        <div class="input-option">
        <label for="iname">Gasto:</label>
        <select name="tipo">
            <option selected>Alimento</option>
        </select>
        </div>
    <?php
        $query_mascota = mysqli_query($conexion, "SELECT * FROM mascota WHERE id_usuario= $idusu");
        $result_mascota = mysqli_num_rows($query_mascota)
    ?>

    <br>
    <div class="input-option">
    <label for="iname">Mascota:</label>
    <select name="mascota">
    <option disabled selected>Seleccione una mascota</option>
    <?php
     if($result_mascota >0)
    {
     while($mascota =mysqli_fetch_array($query_mascota)){
    ?>
    <option value="<?php echo $mascota['nombre']?>"><?php echo $mascota['nombre']?></option>
    <?php
    }


 }

    ?>
    </select>
    </div>

        <div class="input-contenedor">
        <input type="text" placeholder="Nombre del producto" name="nombre_producto" required>

        </div>
    
        <div class="input-contenedor">
            <input type="text" placeholder="Cantidad" name="cantidad" required>

        </div>

        <div class="input-contenedor">
        <input type="number" placeholder="Monto" name="monto" required>
        </div>

        <div class="input-option">
        <label for="iname">Fecha de compra:</label>
        <input type="date" placeholder="Fecha de compra" name="fecha" required>

        </div>

        <div class="input-contenedor">
        <input type="text" placeholder="Ubicacion  (lugar de compra)" name="ubicacion" required>
        </div>

       

        <input type="submit" value="Guardar" class="button">
    </form>
    <div class="input-img">
        <a href="Principal.php">
        <img src="img/Imagen1.png">
        <a href="Principal.php">
    </div>
    <div class="izquierda">
        <div class="foto">
        <img class="izquierda" src="img/logo.png">
    </div>

    <script>
        function atras(){
            history.back();
        }

        function adelante(){
            history.forward();
        }


    </script>


    <button class="boton" onclick="atras()">Atras</button>
    <button class="boton2" onclick="adelante()">Siguiente</button>

</body>
</html>