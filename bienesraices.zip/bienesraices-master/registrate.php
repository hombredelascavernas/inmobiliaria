<?php

include 'conexion.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
/*$consulta="select * from usuarios";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);
*/


//INSERTAR REGISTROS
if(isset($_POST['nombre'])){
    $nombre_usuario=$_POST['nombre_usuario'];
    $usuario=$_POST['usuario'];
    $contraseña=$_POST['contraseña'];
    $telefono=$_POST['telefono'];
    $correo=$_POST['correo'];
    $id_rol=$_POST['id_rol'];
    $id_ciudad=$_POST['id_ciudad'];


    $insertar="insert into usuarios (nombre_usuario, usuario, contraseña, telefono, correo, id_rol,id_ciudad) VALUES 
    ('$nombre_usuario','$usuario','$contraseña','$telefono','$correo','$id_rol','$id_ciudad')";

echo "cadena: ".$insertar;


    if (mysqli_query($conexion,$insertar)){  
        echo "<script>alert('Usuario registrado');</script>";
        echo"<script>window.location='login.php';</script>";
    }
    else{
        echo"<script>alert('Error');</script>";
    }
}

$consulta2= "SELECT*FROM roles";

//especificar error en mysqli_error
$ejecutar=mysqli_query($conexion,$consulta2) or die (mysqli_error($conexion));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <link rel="stylesheet" href="style/register.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css" integrity="sha512-q3eWabyZPc1XTCmF+8/LuE1ozpg5xxn7iO89yfSOd5/oKvyqLngoNGsx8jq92Y8eXJ/IRxQbEC+FGSYxtk2oiw=="crossorigin="anonymous"> 

</head>
<body>
<header>

        <div class="navbar2">
            <img class="logo" src="style/images/logo.svg" alt="logo bienes raices">
            <nav class="nav_links">
                <a href="login.php">Login</a>
                                    
            </nav>
        </div>
    
    </header>
    <section id="registrar">
        <div id="contenedor2">
            <B><h1>REGISTRATE</h1></B>
            <form  action="registrate.php" method="POST" class="register-form">
            <div class="admin-style">
                    <label for="id_usuarios"></label>
                    <input type="hidden" name="id_usuarios" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['id_usuarios']."'disabled "; } ?>placeholder="(No nescesitas introducir nada aqui)" class="register-ipt" readonly><br>
                </div>    
            <div>
                <input type="text" name="nombre_usuario" pattern="[a-z A-ZÀ-ÿ\u00f1\u00d1]{1,20}" title="El nombre no puede incluir caracteres raros y no debe ser mayor a 20 caracteres" placeholder="Nombre" class="register-ipt" requiered>
                <input type="email" name="correo" placeholder="correo" class="register-ipt">
                </div><br>
                <div>
                <input type="text" name="usuario" pattern=".{1,15}" title="El nombre de usuario no debe ser mayor a 15 caracteres" placeholder="Nombre de Usuario" class="register-ipt">
                </div><br>

                <div>
                <input type="password" name="contraseña" pattern=".{6,}" title="La contraseña debe tener minimo 6 caracteres" placeholder="Contraseña" class="register-ipt">
                <input type="text" name="telefono" maxlength="10" placeholder="Teléfono" pattern="[0-9]{10,}" title="Ingrese un número de telefono valido" class="register-ipt">
                </div><br>

               <br><br>

                <div>
                        <label for="id_ciudad">Ciudad:</label>
                        <select name="id_ciudad" id="id_ciudad" class="admin-style-new">
                            <option disabled selected>Seleccione una ciudad:</option>
                         <?php
                         $sql = "SELECT id_ciudad, nombre_ciudad FROM ciudades;";
                            $result = mysqli_query($conexion, $sql);
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['id_ciudad'] . "'>" . $row['nombre_ciudad'] . "</option>";
                            }
                            ?>
                     </select>
                    </div>
              <input type='hidden' name='id_rol' value='2' >
                <div>
                <input type="submit" name="Registrarse" class="register-btn" value="Registrarse">
                </div><br>
            </form>
    </div>
</section>
<footer>
        <div>
            <a href="" >Instagram</a>
            <a href="">Facebook</a>
            <a href="">(993)-300-800</a>
            <a href="">Contacto</a>
        </div>
        <div>
            <p>Todos los derechos reservados ©</p>
        </div>
    </footer>
</body>
</html>