<?php
include 'conexion.php';

session_start();
    $usuario1=$_SESSION['usuario'];
    
    if(!isset($usuario1)){
        header("location:login.php");
    } 

$usuario = mysqli_query($conexion, "SELECT id_usuarios FROM usuarios WHERE usuario='$usuario1'");
$data = mysqli_fetch_array($usuario);
$idusu = $data['id_usuarios'];

// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta="select * from mensajes where id_usuarios= $idusu";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);


if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from mensajes where id_mensajes=$eliminar");
}
?>

<!--<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="style/mensajes.css">


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
</head>
<body class="admin-body">
    <aside class="admin-aside">
        <div class="admin-first">  
            <h1>Bienvenido 
                <?php echo $usuario1 ?> 
            </h1> 
            <img src="style/images/adminpro.png" alt="usuario" class="admin-pic">
            <div class="admin-btn">
                <button class="admin-btn-press">
                    <a href="cerrar.php" class="button_top -orange">Cerrar Sesión</a>
                </button>
            </div>
        </div>  
        <div class="cat-div">
            <a href="menu_vendedor.php">
                <img src="style/images/articulos.png" alt="Pets" class="fku">
                <p>Articulos</p>
            </a>
            <a href="mensajes_vendedor.php">
                <img src="style/images/correo-electronico.png" alt="Shipping" class="fku">
                <p>Mensajes</p>
            </a>
            ---------------------------------------------------------------------------------------------------------- 
        </div>
    </aside>
               
        </div>-->
    <div class="admin-container">
        <div class="view">
            <table>
                <tr class="tr-title">
                    <td>Nombre Completo</td>
                    <td>email</td>
                    <td>telefono</td>
                    <td>mensaje</td>
                    <td>Eliminar</td>
                </tr>
                <?php echo $nfilas;
                
                while($clientes=mysqli_fetch_array($resultado)) {?>
                <input type="text" id="idcont" value="<?php echo $clientes['id_mensajes'] ?>" hidden>

                <tr class="tr-info">
                    <td><?php echo $clientes['nombre']?></td>
                    <td><?php echo $clientes['email']?></td>
                    <td><?php echo $clientes['celular']?></td>
                    <td><?php echo $clientes['mensaje']?></td>
                    <td><a onclick="smsdel2()">Eliminar</a></td>
                </tr>
                <?php }?>
            </table>
        </div>
    </div>
</body>
</html>
