<?php

include 'php/conexion_be.php';
    
session_start();

if(!isset($_SESSION['usuario'])){
    echo '
        <script>
             alert("Por favor debes iniciar sesión");
        window.location = "login.php";
        </script>
   ';
   session_destroy();
   die();
}
 
//PASO 1: CREE LA VARIABLE $persona QUE TOMA EL VALOR DEL USUARIO QUE ESTA DENTRO
//PASO 2: HAGO EL SELECT $usuario PARA TRAER LA INFORMACION DE LA BD DE LA PERSONA QUE ESTA DENTRO DE LA SESION 
//PASO 3: HAGO EL $data PARA CONVERTIR LOS DATOS EN VARIABLES
//PASO 4: HAGO EL INPUT HIDDEN CON LA VARIABLE QUE ACABAMOS DE CREAR DE $idusu
//PASO 5: EN EL FOMR form_mascota en proceso para pasar por metodo POST el nuevo dato que cree
//PASO 6: EN LA BD EN LA TABLA mascota CREE LA COLUMNA id_usuario que es donde almacenare el POST mandado
//PASO 7: EN EL PHP DE dato_mascota EN EL SELECT PIDO QUE TRAIGA LOS DATOS QUE SEAN IGUAL A $idusu   
$persona = $_SESSION['usuario'];

$usuario = mysqli_query($conexion, "SELECT id_usuario, Usuario, Correo FROM usuario WHERE Usuario='$persona'");

$data = mysqli_fetch_array($usuario);

  $idusu = $data['id_usuario'];
  $usu= $data['Usuario'];
  $correo = $data['Correo'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<title></title> 
    <meta http-equiv="X-UA-Compatible" content="width=device-width, user-scalable=yes, initial-scale=1.0, maximum-scale=3.0, minimum-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
       <link rel="stylesheet" href="style.css">


</head>
<body>
    <form action="php/form_mascota.php" method="post" class="formulario">
        <input type="hidden" name="usuario" value="<?php echo $idusu;?>">
        <h1>Datos de la mascota</h1>
        <div class="contenedor">
        
        <div class="input-contenedor">
        <input type="text" placeholder="Nombre" name="nombre" required>

        </div>

        <div class="input-option">
        <label for="iname">Tipo:</label>
        <select name="tipo">
            <option selected>Perro</option>
        </select>
        </div>

        <div class="input-option">
        <label for="iname">Raza:</label>
        <select name="raza">
            <option disabled selected>Seleccione una raza</option>
            <option >Salchicha</option>
            <option >Chihuahua</option>
            <option >Pitbull</option>
            <option >Pastor aleman</option>
            <option >Mestizo (cruze)</option>
        </select>
        </div>


        <div class="input-contenedor">
        <input type="text" placeholder="Color" name="color" required>
        </div>

        <div class="input-option">
        <label for="iname">Sexo:</label>
        <select name="sexo">
            <option disabled selected>Seleccione una opción</option>
            <option >Macho</option>
            <option >Hembra</option>
        </select>
        </div>

        <div class="input-contenedor">
        <input type="text" placeholder="Señas particulares" name="senas" required>
        </div>

        <div class="input-contenedor">
        <input type="text" placeholder="Edad" name="edad" required>
        </div>

        <input type="submit" value="Guardar" class="button">
    </form>
    <div class="input-img">
        <img src="img/Imagen1.png">
    </div>
    <div class="izquierda">
        <div class="foto">
        <img class="izquierda" src="img/logo.png">
    </div>


    <script>
        function atras(){
            history.back();
        }

        function adelante(){
            history.forward();
        }


    </script>


    <button class="boton" onclick="atras()">Atras</button>
    <button class="boton2" onclick="adelante()">Siguiente</button>

</body>
</html>