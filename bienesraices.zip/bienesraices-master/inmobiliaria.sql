-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 30-11-2023 a las 21:09:05
-- Versión del servidor: 8.0.17
-- Versión de PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inmobiliaria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `casas`
--

CREATE TABLE `casas` (
  `id_casa` int(11) NOT NULL,
  `nombre_casa` varchar(150) DEFAULT NULL,
  `imagen` varchar(50) DEFAULT '0',
  `estatus` bit(1) NOT NULL DEFAULT b'0',
  `habitaciones` int(11) NOT NULL,
  `baños` int(11) NOT NULL,
  `carro` int(11) NOT NULL,
  `m2` int(11) NOT NULL,
  `ubicacion` varchar(150) NOT NULL,
  `descripcion` text NOT NULL,
  `id_usuarios` int(11) NOT NULL,
  `id_venta` int(11) NOT NULL,
  `id_ciudad` int(11) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `casas`
--

INSERT INTO `casas` (`id_casa`, `nombre_casa`, `imagen`, `estatus`, `habitaciones`, `baños`, `carro`, `m2`, `ubicacion`, `descripcion`, `id_usuarios`, `id_venta`, `id_ciudad`, `precio`) VALUES
(2, 'Renta DE CASA EN Plaza Villahermosa Centro Tabasco', 'style/images/anuncio1.jpg', b'1', 2, 3, 1, 100, 'Mexico', '¡¡¡EXCELENTE OPORTUNIDAD DE INVERSIÓN¡¡¡\r\n\r\nAdquiere un inmueble por DEBAJO de su COSTO COMERCIAL\r\n\r\nSOLO PAGO DE CONTADO\r\n\r\nExcelente ubicación, cerca de vialidades principales, ideal para ti que quieres vivir cerca de tu trabajo u oficina.\r\n\r\nUBICADO EN LA CALLE: Nardos \r\nEN LA COLONIA: Plaza Villahermosa\r\nCentro, Tabasco\r\n\r\nNO SE ACEPTAN CRÉDITOS\r\n(INFONAVIT, FOVISSSTE, HIPOTECARIO)\r\n\r\nBRINDAMOS ASESORÍA PROFESIONAL.\r\n\r\nCesión de derechos ante notario público\r\n\r\nEntrega garantizada, contáctame.\r\n\r\nContacto: EVA BARRAGAN | | evabarragan@zumainversiones.com.mx\r\n\r\n* Precios y disponibilidad sujetos a cambios* \r\n\r\nEXCELENTE INVERSIÓN INMOBILIARIA.', 2, 2, 5, '10000.00'),
(3, 'Venta DE TERRENO EN Fraccionamiento Los Pinos Guadalajara Jalisco', 'style/images/anuncio3.jpg', b'1', 3, 2, 1, 150, 'Mexico', '¡¡¡OPORTUNIDAD ÚNICA PARA INVERTIR!!! Aprovecha esta oferta excepcional para adquirir una propiedad por DEBAJO de su VALOR DE MERCADO. Pago exclusivamente al CONTADO. Su ubicación es inmejorable, con acceso rápido a las principales vías, perfecta para aquellos que buscan residir cerca de su empleo o negocio. SITUADA EN: Calle Girasoles UBICADA EN EL BARRIO: Plaza Villahermosa Centro, Tabasco. No se admiten modalidades de pago mediante crédito (INFONAVIT, FOVISSSTE, hipotecas). Ofrecemos orientación de expertos en el campo inmobiliario. Formalización legal ante notario para tu seguridad. Garantizamos la entrega puntual. ¡No dejes pasar esta oportunidad! Comunícate con: JUAN CRUZ | | juancruz@zumainversiones.com.mx Sujeto a modificaciones en precios y disponibilidad EXCELENTE INVERSIÓN EN BIENES RAÍCES.', 2, 1, 3, '10000.00'),
(9, 'Alquiler DE BODEGA EN Parque Industrial Santa Fe Querétaro Querétaro', 'style/images/anuncio1.jpg', b'0', 22, 2, 2, 3, 'Mexico\r\n', '¡¡¡TU FUTURO PATRIMONIO TE ESPERA!!! Invierte sabiamente al adquirir una propiedad por DEBAJO de su VALOR COMERCIAL REAL, solo con PAGO AL CONTADO. Su ubicación es estratégica y conveniente, con acceso a las principales vías, especialmente diseñada para quienes desean vivir cerca de su lugar de trabajo o estudio. UBICACIÓN: Avenida Orquídeas EN LA ZONA: Plaza Villahermosa Centro, Tabasco. No se aceptan modalidades de pago mediante créditos (INFONAVIT, FOVISSSTE, hipotecas). Te brindamos asesoramiento profesional y ético. Formalidad notarial para cierre de trato. Entrega garantizada y puntual. ¡Contáctanos ya mismo! Datos de contacto: MARÍA FLORES | | mariaflores@zumainversiones.com.mx Precios y disponibilidad sujetos a cambios UNA INMEJORABLE INVERSIÓN INMOBILIARIA.', 4, 1, 4, '200000.00'),
(11, 'Venta DE EDIFICIO EN Zona Universitaria Mérida Yucatán', 'style/images/anuncio5.jpg', b'0', 12, 2, 3, 45, 'Mexico', '¡¡¡HAZ REALIDAD TU INVERSIÓN IDEAL!!! Adquiere ahora un inmueble por un COSTO SIGNIFICATIVAMENTE INFERIOR a su VALOR EN EL MERCADO. Solo requerimos PAGO TOTAL EN EFECTIVO. Su UBICACIÓN es excepcional, cercana a las principales arterias viales, perfecta para aquellos que desean residir cerca de su lugar de empleo o estudio. LOCALIZACIÓN: Calle Tulipanes EN EL SECTOR: Plaza Villahermosa Centro, Tabasco. No están habilitadas las opciones de financiamiento (INFONAVIT, FOVISSSTE, hipotecas). Proporcionamos asesoría especializada y confiable. Transferencia de derechos ante notario para seguridad de ambas partes. Garantizamos una entrega oportuna y satisfactoria. ¡No dejes pasar esta oportunidad enriquecedora! Comunícate a: CARLOS GÓMEZ | | carlosgomez@zumainversiones.com.mx Sujeto a cambios en tarifas y disponibilidad TU MEJOR INVERSIÓN EN BIENES RAÍCES.', 2, 1, 0, '300000.00'),
(12, 'Venta DE DEPARTAMENTO EN Colonia Juárez Norte Oaxaca de Juarez', 'style/images/anuncio4.jpg', b'0', 12, 2, 3, 45, 'Mexico', '¡Invierte ahora y asegura tu futuro en bienes raíces! Oportunidad única para adquirir una propiedad por debajo de su valor real, en efectivo y con ubicación privilegiada. No se aceptan modalidades de pago por crédito. Contáctanos: ANA MARTÍNEZ | anamartinez@zumainversiones.com.mx | Cambios sujetos a disponibilidad.', 15, 1, 5, '200000.00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudades`
--

CREATE TABLE `ciudades` (
  `id_ciudad` int(11) NOT NULL,
  `nombre_ciudad` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `ciudades`
--

INSERT INTO `ciudades` (`id_ciudad`, `nombre_ciudad`) VALUES
(0, 'Tlaxcala '),
(1, 'CDMX'),
(2, 'Cancún'),
(3, 'Mérida'),
(4, 'Tuxtla Gutiérrez'),
(5, 'Villahermosa'),
(6, 'Veracruz'),
(7, 'Oaxaca de Juárez'),
(8, 'Acapulco'),
(9, 'Campeche'),
(10, 'Chetumal'),
(11, 'Monterrey'),
(12, 'Aguas Cientes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contacto`
--

CREATE TABLE `contacto` (
  `id_contacto` int(11) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `mensaje` text NOT NULL,
  `id_casa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `contacto`
--

INSERT INTO `contacto` (`id_contacto`, `nombre`, `email`, `telefono`, `mensaje`, `id_casa`) VALUES
(9, 'sfert', 'df@rferg', '3456456', '345456', NULL),
(10, 'Carlos Torres', 'josecarlost840@gmail.com', '993455223', 'esta es una preuba de evaluacion', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `id_mensajes` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `mensaje` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `celular` varchar(10) NOT NULL,
  `id_casa` int(11) NOT NULL,
  `id_usuarios` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id_mensajes`, `nombre`, `mensaje`, `email`, `celular`, `id_casa`, `id_usuarios`) VALUES
(11, 'Jose Carlos Torres Cardenas', 'muy buenas noches quisiera comprar su casa. ', 'jctc02@hotmail.com', '9935698844', 11, 2),
(14, 'wertyui', 'tyureew43567', 'sdfghj@', '345678887', 12, 15),
(17, 'jigtyh', 'dfgfyhyujuyj', 'ejemplo@hotmail.com', '2356577657', 3, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL,
  `nombre_rol` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `nombre_rol`) VALUES
(1, 'administrador'),
(2, 'vendedor'),
(3, 'cliente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuarios` int(11) NOT NULL,
  `nombre_usuario` varchar(120) DEFAULT NULL,
  `usuario` varchar(40) NOT NULL,
  `contraseña` varchar(40) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `id_ciudad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuarios`, `nombre_usuario`, `usuario`, `contraseña`, `telefono`, `correo`, `id_rol`, `id_ciudad`) VALUES
(2, 'Jesus Alfredo Domínguez', 'jugador', '123456', '9945734855', 'alfredo@gmail.com', 2, 4),
(4, 'Yesenia López Sánchez', 'yese', '123', '9932939293', 'yesenia@gmail.com', 2, 1),
(9, 'Juan García Hernández', 'juan', '123', '9932758394', 'sdfsdf@gmail.com', 1, 2),
(15, 'Andrea Martínez González', 'superpepinilloo', '123456', '9943546789', 'ejemplo2@gmail.com', 2, 5),
(17, 'Carlos Ramírez López', 'ejemplo', '123456', '9975646372', 'ejemplo@gmail.com', 2, 5),
(27, 'Jose Carlos', 'siuu', '123', '3945678789', 'josecarlost840@gmail.com', 1, 2),
(47, 'prueba', 'prueba', '123', '9999999999', 'prueba@prueba.com', 1, 1),
(48, 'ejemplo', 'ejemplo', 'ejejmplo', '6868686858', 'ejemplo@gmail.com', 2, 2),
(49, 'preuba de registro para evaluacion', 'jg756161@gmail.com', '234234234', '123123123', 'josecarlost840@gmail.com', 3, 1),
(54, 'ivan', 'smile', '321', '9932895622', 'iv@gmail.com', 2, 5),
(56, 'ivaaan', 'smileee', '321', '1234567890', 'ivhs@gmail.com', 3, 5),
(57, 'ivaaan', 'smileee', '321', '1234567890', 'ivhs@gmail.com', 3, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE `venta` (
  `id_venta` int(11) NOT NULL,
  `nombre_venta` varchar(40) DEFAULT NULL,
  `id_contacto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `venta`
--

INSERT INTO `venta` (`id_venta`, `nombre_venta`, `id_contacto`) VALUES
(1, 'Venta', NULL),
(2, 'Renta', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `casas`
--
ALTER TABLE `casas`
  ADD PRIMARY KEY (`id_casa`),
  ADD KEY `id_usuarios` (`id_usuarios`),
  ADD KEY `id_ventas` (`id_venta`),
  ADD KEY `fk_casas_ciudades` (`id_ciudad`);

--
-- Indices de la tabla `ciudades`
--
ALTER TABLE `ciudades`
  ADD PRIMARY KEY (`id_ciudad`);

--
-- Indices de la tabla `contacto`
--
ALTER TABLE `contacto`
  ADD PRIMARY KEY (`id_contacto`),
  ADD KEY `fk_contacto_casas` (`id_casa`);

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`id_mensajes`),
  ADD KEY `id_casa` (`id_casa`),
  ADD KEY `id_usuario` (`id_usuarios`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuarios`),
  ADD KEY `id_rol` (`id_rol`),
  ADD KEY `fk_usuarios_ciudades` (`id_ciudad`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`id_venta`),
  ADD KEY `fk_venta_contacto` (`id_contacto`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `casas`
--
ALTER TABLE `casas`
  MODIFY `id_casa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `contacto`
--
ALTER TABLE `contacto`
  MODIFY `id_contacto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  MODIFY `id_mensajes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuarios` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT de la tabla `venta`
--
ALTER TABLE `venta`
  MODIFY `id_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `casas`
--
ALTER TABLE `casas`
  ADD CONSTRAINT `casas_ibfk_1` FOREIGN KEY (`id_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `casas_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `venta` (`id_venta`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_casas_ciudades` FOREIGN KEY (`id_ciudad`) REFERENCES `ciudades` (`id_ciudad`);

--
-- Filtros para la tabla `contacto`
--
ALTER TABLE `contacto`
  ADD CONSTRAINT `fk_contacto_casas` FOREIGN KEY (`id_casa`) REFERENCES `casas` (`id_casa`);

--
-- Filtros para la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD CONSTRAINT `mensajes_ibfk_1` FOREIGN KEY (`id_casa`) REFERENCES `casas` (`id_casa`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mensajes_ibfk_2` FOREIGN KEY (`id_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuarios_ciudades` FOREIGN KEY (`id_ciudad`) REFERENCES `ciudades` (`id_ciudad`),
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `venta`
--
ALTER TABLE `venta`
  ADD CONSTRAINT `fk_venta_contacto` FOREIGN KEY (`id_contacto`) REFERENCES `contacto` (`id_contacto`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
