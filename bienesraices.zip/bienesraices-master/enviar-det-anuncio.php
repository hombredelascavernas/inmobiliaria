<?php
include 'conexion.php';
/* CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta3="select * from mensajes";
$resultado3=mysqli_query($conexion,$consulta3);
$nfilas=mysqli_num_rows($resultado3);*/

//verifico si se recibe la variable r
if(isset($_GET['r'])){
    
    // Obtiene el valor de 'r' y lo decodifica desde la URL en un formato json
    $jsonData = $_GET['r'];
    $dataArray = json_decode($jsonData, true);

    //INSERTAR REGISTROS
    
    $nombre=$dataArray[0];//accedo a las partes correspondientes del array de acuerdo con su posicio
    $mensaje=$dataArray[1];
    $email=$dataArray[2];
    $celular=$dataArray[3];
    $id_casa=$dataArray[4];
    $id_usuarios=$dataArray[5];
    
    
    $insertar="INSERT INTO mensajes (nombre, mensaje, email, celular, id_casa, id_usuarios) VALUES ('$nombre','$mensaje','$email','$celular','$id_casa','$id_usuarios')";

    /*quite el campo de id_mensajes pues en el html no manejas un campo con ese nombre y el valor permanece vacio lo que manda un error
    ademas tienes la opcion autoincrementable en la base de datos por lo que no es necesario agregar un valor a este campo manualmente
    $insertar="insert into mensajes (id_mensajes,nombre, mensaje, email, celular, id_casa, id_usuarios) VALUES ('$id_mensajes','$nombre','$mensaje','$email','$celular','$id_casa','$id_usuarios')";*/
    $eje = mysqli_query($conexion, $insertar);
    /*
    defino el estado de la consulta para que en caso de ser exitosa prosiga de forma esperada
    y en caso de haber algun error mandar un mensaje de error
    esta parte se sigue manejando en el javascript
    */ 
    if($eje){
        $response = array("status" => "success", "message" => "Entrada registrada con éxito.");
    http_response_code(200);

    echo json_encode($response);//vuelvo la respuesta en forma de json para que js pueda trabajar con ella
    }else{
        $response = array("status" => "failed", "message" => "error al registrar entrada.");
    http_response_code(500);

    echo json_encode($response);
    }
    /*comente esta parte para que no se ejecutara pero la deje en caso de que la necesites para algo
    
    if($eje){
        /*echo '
        <script>
           alert("Gasto almacenado exitosamente");
           window.location = "anuncios.php";
        </script>
        ';
    }/*else{
        echo'
        <script>
           alert("Parece que hubo un error, los datos no se guardaron");
           window.location = "anuncios.php";
        </script>
        ';
    }*/

    mysqli_close($conexion);
} else {
    echo "<h1>no se recibio variable</h1>";
}



?>