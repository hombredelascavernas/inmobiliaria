<?php
$host = "localhost"; #cambie este campo, en el original era 'localhost'
$usuario = "root";
$password = "12346789"; #cambie este campo, en el original no tenia valor ""
$base_datos = "inmobiliaria";

$conexion = mysqli_connect($host, $usuario, $password, $base_datos);

if (!$conexion) {
    die("Error al conectar a la base de datos: " . mysqli_connect_error());
}
?>
