

<div class="anuncio">
<img src="<?php echo $data['imagen']; ?>" alt="">
<h3><?php echo $data['nombre_casa']; ?></h3><br>
<p class="precio">$<?php echo $data['precio'];?></p><br>

<div class="iconos">
    <img src="style/images/icono_wc.svg" alt=""> <span><?php echo $data['baños']; ?></span>
    <img src="style/images/icono_estacionamiento.svg" alt=""> <span><?php echo $data['carro']; ?></span>
    <img src="style/images/icono_dormitorio.svg" alt=""> <span><?php echo $data['habitaciones']; ?></span>
</div>

<a href="det_anuncio.php?id_casa=<?php echo $data['id_casa']; ?>"><button>Contactar</button></a>
</div>
