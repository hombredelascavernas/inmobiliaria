<?php
include 'conexion.php';
session_start();

if(!isset($_SESSION['usuario'])){
    echo '
        <script>
             alert("Por favor debes iniciar sesión");
        window.location = "login.php";
        </script>
   ';
   session_destroy();
   die();
}

$persona = $_SESSION['usuario'];

$usuario = mysqli_query($conexion, "SELECT id_usuarios, usuario, correo FROM usuarios WHERE usuario='$persona'");

$data = mysqli_fetch_array($usuario);
$idusu = $data['id_usuarios'];
$usu= $data['usuario'];
$correo = $data['correo'];

// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta=mysqli_query($conexion,"select casas.*,venta.nombre_venta, ciudades.nombre_ciudad 
from casas
join venta on casas.id_venta=venta.id_venta
join ciudades on ciudades.id_ciudad=casas.id_ciudad
where id_usuarios='$idusu'");
$casas=mysqli_fetch_array($consulta);

?>
<?php
$consulta3="select * from casas";
$resultado=mysqli_query($conexion,$consulta3);
$nfilas=mysqli_num_rows($resultado);

//INSERTAR REGISTROS
if(isset($_REQUEST['id_casa']) && !isset($_REQUEST['clave'])){
    $id_casa = $_REQUEST['id_casa'];
    $nombre_casa = $_REQUEST['nombre_casa'];
    $imagen = $_FILES['imagen']['tmp_name']; // Ruta temporal del archivo
    if (empty($imagen)) {
        echo "<script>alert('Debes seleccionar una imagen');</script>";
    } else {
        // Procesar el archivo cargado aquí
        $imagen_name = $_FILES['imagen']['name'];
        $imagen_destination = 'style/images/' . $imagen_name; // Cambia esta ruta

        move_uploaded_file($imagen, $imagen_destination);}

    $precio = $_REQUEST['precio'];
    $habitaciones = $_REQUEST['habitaciones'];
    $baños = $_REQUEST['baños'];
    $carro = $_REQUEST['carro'];
    $m2 = $_REQUEST['m2'];
    $ubicacion = $_REQUEST['ubicacion'];
    $descripcion = $_REQUEST['descripcion'];
    $estatus= $_REQUEST['estatus'];
    $id_venta = $_REQUEST['id_venta'];
    $id_ciudad= $_REQUEST['id_ciudad'];
    $insertar = "INSERT INTO casas (nombre_casa, imagen, precio, habitaciones, baños, carro, m2,ubicacion, descripcion, estatus, id_usuarios, id_venta,id_ciudad,id_casa) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";
    $stmt = mysqli_prepare($conexion, $insertar);
    mysqli_stmt_bind_param($stmt, "ssiiiiissiiiii", $nombre_casa, $imagen, $precio, $habitaciones, $baños, $carro, $m2, $ubicacion, $descripcion, $estatus, $idusu, $id_venta,$id_ciudad,$id_casa);
    $subio = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    if ($subio) {
        echo "<script>alert('Casa registrada');</script>";
        } else {
        echo "<script>alert('Error al insertar un registro, ==> recuerda rellenar todos los campos');</script>";}}
//ELIMINAR REGISTROS
if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from casas where id_casa=$eliminar");
    echo "<script>alert('Casa borrada');</script>";
    echo"<script>window.location='menu_vendedor.php';</script>";
}

//EDITAR REGISTROS
//1.Consulta el registro que va editar
if(isset($_REQUEST['editar'])){
    $editar = $_REQUEST['editar'];
    $registros1 = mysqli_query($conexion, "SELECT * FROM casas WHERE id_casa=$editar");
    $reg = mysqli_fetch_array($registros1);
}
//2.Actualiza el Registro
if(isset($_REQUEST['clave'])){
    $id_casa = $_REQUEST['clave'];
    $nombre_casa = $_REQUEST['nombre_casa'];
    $imagen = $_FILES['imagen']['tmp_name']; // Ruta temporal del archivo
    $precio = $_REQUEST['precio'];
    $habitaciones = $_REQUEST['habitaciones'];
    $baños = $_REQUEST['baños'];
    $carro = $_REQUEST['carro'];
    $m2 = $_REQUEST['m2'];
    $ubicacion = $_REQUEST['ubicacion'];
    $descripcion = $_REQUEST['descripcion'];
    $estatus= $_REQUEST['estatus'];
    $id_venta = $_REQUEST['id_venta'];
    $id_ciudad= $_REQUEST['id_ciudad'];

    if (!empty($imagen)) {
        // Si se ha subido una nueva imagen, procesarla y actualizar la ruta
        $imagen_name = $_FILES['imagen']['name'];
        $imagen_destination = 'style/images/' . $imagen_name; // Cambia esta ruta
        move_uploaded_file($imagen, $imagen_destination);
    } else {
        // Si no se ha subido una nueva imagen, mantener la imagen anterior
        $imagen_destination = $_REQUEST['archivo_mod'];
    }
    $actualizar = "UPDATE casas SET nombre_casa=?,imagen=?, precio=?, habitaciones=?, baños=?, carro=?, m2=?, ubicacion=?, descripcion=?, estatus=?, id_usuarios=?, id_venta=?, id_ciudad=? 
                WHERE id_casa=?";
    $stmt = mysqli_prepare($conexion, $actualizar);
    mysqli_stmt_bind_param(
        $stmt,
        "ssiiiiissiiiii",
        $nombre_casa,
        $imagen_destination, // Usamos la ruta donde guardamos la imagen
        $precio,
        $habitaciones,
        $baños,
        $carro,
        $m2,
        $ubicacion,
        $descripcion,
        $estatus,
        $idusu,
        $id_venta,
        $id_ciudad,
        $id_casa
    );
    $subio = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    if ($subio) {
        echo "<script>alert('Casa Actualizada');</script>";
        } 
    else {
        echo "<script>alert('Error al editar');</script>";}}
    /*
    if(empty($imagen)){
        $imagen1 = $_REQUEST['archivo_mod'];
        $actualizar = "UPDATE casas SET nombre_casa=?,imagen=?, precio=?, habitaciones=?, baños=?, carro=?, m2=?, ubicacion=?, descripcion=?, estatus=?, id_usuarios=?, id_venta=?, id_ciudad=? 
                       WHERE id_casa=?";
        $stmt = mysqli_prepare($conexion, $actualizar);
        mysqli_stmt_bind_param($stmt, "ssiiiiissiiiii", $nombre_casa, $imagen1, $precio, $habitaciones, $baños, $carro, $m2, $ubicacion, $descripcion, $estatus, $id_usuarios, $id_venta,$id_ciudad,$id_casa);
    } else {
        $actualizar = "UPDATE casas SET nombre_casa=?,imagen=?, precio=?, habitaciones=?, baños=?, carro=?, m2=?, ubicacion=?, descripcion=?, estatus=?, id_usuarios=?, id_venta=?, id_ciudad=? 
                        WHERE id_casa=?";
        $stmt = mysqli_prepare($conexion, $actualizar);
        mysqli_stmt_bind_param($stmt, "ssiiiiissiiiii", $nombre_casa, $imagen, $precio, $habitaciones, $baños, $carro, $m2, $ubicacion, $descripcion, $estatus, $id_usuarios, $id_venta,$id_ciudad,$id_casa);
    }
    $subio = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    if ($subio) {
        echo "<script>alert('Casa Actualizada');</script>";
        echo "<script>window.location='cat_articulos.php';</script>";} 
    else {
        echo "<script>alert('Error al editar');</script>";}}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="style/mainadmin.css">


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="http://localhost/php/bienesraices-master/js/jsfiles.js"></script>

</head>
<body class="admin-body">
    <aside class="admin-aside">
        <div class="admin-first">  
            <h1>Bienvenido 
                <?php echo $usu?> 
            </h1> 
            <img src="style/images/adminpro.png" alt="usuario" class="admin-pic">
            <div class="admin-btn">
                <button class="admin-btn-press">
                    <a href="cerrar.php" class="button_top -orange">Cerrar Sesión</a>
                </button>
            </div>
        </div>  
        <div class="cat-div">
            <a onclick="menuvendedor()">
                <img src="style/images/articulos.png" alt="Pets" class="fku">
                <p>Articulos</p>
            </a>
            <a onclick="messaggesvend()">
                <img src="style/images/correo-electronico.png" alt="Shipping" class="fku">
                <p>Mensajes</p>
            </a>
             
        </div>
    </aside>
    <div class="admin-container" id="module5">
        <div class="edite">
            <form class="admin-cli-edite" action="menu_vendedor.php" method="POST" enctype="multipart/form-data">
                <div class="admin-style">
                  <label for="id_casa"></label>
                    <input type="hidden" name="id_casa" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['id_casa']."'disabled "; } ?>placeholder="Clave" class="register-ipt" readonly><br>
                    <label for="nombre_casa">Titulo del articulo</label>
                    <input type="text" name="nombre_casa" pattern="[a-z A-ZÀ-ÿ\u00f1\u00d1]{1,150}" title="El nombre no puede incluir caracteres raros y no debe ser mayor a 150 caracteres" placeholder="Titulo" class="register-ipt" id="nombre_casa" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['nombre_casa']."' "; } ?>>
    </div>
                <div class="admin-style">
                    <label for="precio">Precio</label>
                    <input type="number" name="precio" pattern="{1,100}" title="No debe ser mayor a 100 caracteres" placeholder="Precio" class="register-ipt" id="precio" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['precio']."' "; } ?>>
                    <label for="habitaciones">Habitaciones</label>
                    <input type="number" name="habitaciones" pattern="{1,2}"  placeholder="Habitaciones" class="register-ipt" id="habitaciones" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['habitaciones']."' "; } ?>>
                </div>
                <div class="admin-style">
                    <label for="baños">Baños</label>
                    <input type="number" name="baños" pattern=".{1,2}"  placeholder="Baños de la propiedad" class="register-ipt" id="usuario" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['baños']."' "; } ?>>
                    <label for="carro">Capacidad del garaje</label>
                    <input type="number" name="carro" placeholder="Gareges de la propiedad" class="register-ipt" id="carro" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['carro']."' "; } ?>>
                    <label for="m2">Metros Cuadrados</label>
                    <input type="number" name="m2"  placeholder="Metros Cuadrados del Terreno" class="register-ipt" id="m2" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['m2']."' "; } ?>>
                </div>
                <div class="admin-style">
                    <label for="descripcion">Descripción</label>
                    <textarea name="descripcion" id="descripcion" cols="29" rows="3" class="admin-area"><?php if(isset($_REQUEST['editar'])) {echo $reg['descripcion']; } ?></textarea>
                </div>
                <div class="admin-style">
                    <label for="estatus">Estatus</label>
                    <select name="estatus" id="estatus" class="admin-style-new">
                        <option disabled selected> Selecciona un estatus</option>
                        <option value="0" <?php if(isset($_REQUEST['editar']) && $reg['estatus'] == 0) { echo "selected"; } ?>>Disponible</option>
                        <option value="1" <?php if(isset($_REQUEST['editar']) && $reg['estatus'] == 1) { echo "selected"; } ?>>Ocupado</option>
                    </select>
                    <label for="ubicacion">Localizacion de la propiedad</label>
                    <textarea name="ubicacion" id="ubicacion" cols="29" rows="3" class="admin-area"><?php if(isset($_REQUEST['editar'])) {echo $reg['ubicacion']; } ?></textarea>
                </div>
               <div class="admin-style">
               <span class="admin-btn-press">
                <label for="imagen" class="button_top -purple">Selecciona una Imágen</label>
                   <input type="file" name="imagen" accept="images/*" id="imagen">
                   </span>
                </div>
                <div class="admin-style-new">
                <select name="id_venta" id="id_venta" class="admin-style-new">
                    <option disabled selected>Venta/Renta</option>
                    <option value="1" <?php if(isset($_REQUEST['editar']) && $reg['id_venta'] == 1) { echo "selected"; } ?>>Venta</option>
                    <option value="2" <?php if(isset($_REQUEST['editar']) && $reg['id_venta'] == 2) { echo "selected"; } ?>>Renta</option>
                </select><br>
                <select name="id_ciudad" id="id_ciudad" class="admin-style-new">
                <option disabled selected>Seleccione una ciudad:</option>
                <?php
                $sql = "SELECT id_ciudad, nombre_ciudad FROM ciudades;";
                $result = mysqli_query($conexion, $sql);
                while ($row = mysqli_fetch_assoc($result)) {
                    $selected = ($row['id_ciudad'] == $reg['id_ciudad']) ? "selected" : "";
                    echo "<option value='" . $row['id_ciudad'] . "' $selected>" . $row['nombre_ciudad'] . "</option>";}
                ?>
                </select>
                </div>
                <?php 
                if(isset($_REQUEST['editar'])) {
                    echo "<input type='hidden' name='clave' value='".$reg['id_casa']."' >";
                    echo "<input type='hidden' name='archivo_mod' value='".(isset($reg['imagen']) ? $reg['imagen'] : '')."'>";}?>
                    
                <span class="admin-btn-press">
                    <input type="submit" name="Aceptar" class="button_top -red" value="Aceptar"> </span>
            </form>
        </div>

        <div class="view">
            <table>
                <tr class="tr-title">
                    <td>Clave Casa</td>
                    <td>Titulo del articulo</td>
                    <td>Imagen</td>
                    <td>Precio</td>
                    <td>Habitaciones</td>
                    <td>Baños</td>
                    <td>Garaje (capacidad)</td>
                    <td>m2</td>
                    <td>Ubicacion</td>
                    <td>Descripción</td>
                    <td>Estatus</td>
                    <td>Venta/Renta</td>
                    <td>Ciudad</td>
                    <td>Editar</td>
                    <td>Eliminar</td>

                </tr>
                <?php if ($casas !== null) {

do{?>
    <tr class="tr-info">
        <td><?php echo $casas['nombre_casa']?></td>
        <td><img src="<?php echo $casas['imagen']?>" alt="<?php echo $casas['imagen']?>"></td>
        <td><?php echo $casas['precio']?></td>
        <td><?php echo $casas['habitaciones']?></td>
        <td><?php echo $casas['baños']?></td>
        <td><?php echo $casas['carro']?></td>
        <td><?php echo $casas['m2']?></td>
        <td><?php echo $casas['ubicacion']?></td>
        <td><?php echo $casas['descripcion']?></td>
        <td><?php  
        if ($casas['estatus']==0)
        {echo "Disponible";}
        else
        {echo "Ocupado";}?>
        </td>
        <td><?php echo $casas['nombre_venta']?></td>
        <td><?php echo $casas['nombre_ciudad']?></td>
        <td><a href="menu_vendedor.php?editar=<?php echo $casas['id_casa']; ?>">Editar</a></td>
        <td><a href="menu_vendedor.php?eliminar=<?php echo $casas['id_casa']; ?>">Eliminar</a></td>
    </tr>
    <?php }while($casas=mysqli_fetch_array($consulta));} else {
    // El arreglo es nulo, maneja este caso apropiadamente
    
}?>
            </table>
        </div>
    </div>
</body>
</html>
