<?php
session_start();
    $usuario1=$_SESSION['usuario'];
    
    if(!isset($usuario1)){
        header("location:login.php");
    }
try {
    include 'conexion.php';
// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta = "SELECT usuarios.*, ciudades.nombre_ciudad, roles.nombre_rol
 FROM usuarios 
 join roles on roles.id_rol=usuarios.id_rol
 JOIN ciudades ON usuarios.id_ciudad = ciudades.id_ciudad;";
$resultado = mysqli_query($conexion, $consulta);
$nfilas = mysqli_num_rows($resultado);   
          
} catch (Exception $e) {
    // Manejo de excepciones
    echo "Error en la consulta: " . $e->getMessage();}
//INSERTAR REGISTROS
if(isset($_GET['responseajax'])){
    $jsondata = $_GET['responseajax'];
    $arr = json_decode($jsondata, true);
    $nombre_usuario=$arr[0];
    $usuario=$arr[1];
    $contraseña=$arr[2];
    $telefono=$arr[3];
    $id_ciudad=$arr[4];
    $correo=$arr[5];
    $id_rol=$arr[6];
    $subio=true;
        if($subio){
            $insertar="insert into usuarios ( nombre_usuario, usuario, contraseña,telefono,id_ciudad,correo,id_rol) VALUES('$nombre_usuario','$usuario','$contraseña','$telefono','$id_ciudad','$correo','$id_rol')";
            mysqli_query($conexion,$insertar);
            
        }
else{
    echo"<script>alert('Error');</script>";
}
}
/*if(isset($_REQUEST['id_usuarios']) && !isset($_REQUEST['clave'])){
    $id_usuarios=$_REQUEST['id_usuarios'];
    $nombre_usuario=$_REQUEST['nombre_usuario'];
    $usuario=$_REQUEST['usuario'];
    $contraseña=$_REQUEST['contraseña'];
    $telefono=$_REQUEST['telefono'];
    $telefono=$_REQUEST['telefono'];
    $id_ciudad=$_REQUEST['id_ciudad'];
    $correo=$_REQUEST['correo'];
    $id_rol=$_REQUEST['id_rol'];
    $subio=true;
        if($subio){
            $insertar="insert into usuarios (id_usuarios, nombre_usuario, usuario, contraseña,telefono,id_ciudad,correo,id_rol) VALUES('$id_usuarios','$nombre_usuario','$usuario','$contraseña','$telefono','$id_ciudad','$correo','$id_rol')";
            mysqli_query($conexion,$insertar);
            echo "<script>alert('Usuario registrado');</script>";
            echo"<script>window.location='menu_admin.php';</script>";
            
        }
else{
    echo"<script>alert('Error');</script>";
}
}*/
//ELIMINAR REGISTROS
if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from usuarios where id_usuarios=$eliminar");
    echo "<script>alert('Usuario borrado');</script>";
    echo"<script>window.location='menu_admin.php';</script>";
}

//EDITAR REGISTROS
//1.Consulta el registro que va editar
if(isset($_REQUEST['editar'])){
    $editar=$_REQUEST['editar'];
    $registros1=mysqli_query($conexion, "select * from usuarios where id_usuarios=$editar");
    $reg=mysqli_fetch_array($registros1);
}
//2.Actualiza el Registro
if(isset($_REQUEST['clave'])){
    $id_usuarios=$_REQUEST['clave'];
    $nombre_usuario=$_REQUEST['nombre_usuario'];
    $usuario=$_REQUEST['usuario'];
    $contraseña=$_REQUEST['contraseña'];
    $telefono=$_REQUEST['telefono'];
    $id_ciudad=$_REQUEST['id_ciudad'];
    $correo=$_REQUEST['correo'];
    $id_rol=$_REQUEST['id_rol'];
        $subio=true;
        if($subio){
            mysqli_query($conexion, "update usuarios set nombre_usuario='$nombre_usuario', usuario='$usuario', contraseña='$contraseña', telefono='$telefono', id_ciudad='$id_ciudad', correo='$correo', id_rol='$id_rol' where id_usuarios='$id_usuarios'");
            echo "<script>alert('Usuario actualizado');</script>";
            echo"<script>window.location='menu_admin.php';</script>";}
        else{
            echo"<script>alert('Error');</script>";}}
?>
 <div class="admin-container">
        <div class="edite">
           <form name="update_form" id="userForm" class="admin-cli-edite"  enctype="multipart/form-data">
                 <div class="admin-style">
                    <label for="id_usuarios"></label>
                    <input type="hidden" name="id_usuarios" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['id_usuarios']."'disabled "; } ?>placeholder="(No nescesitas introducir nada aqui)" class="register-ipt" readonly><br>
                </div>
                <div class="admin-style">
                    <label for="nombre">Nombre</label>
                    <input type="text" name="nombre_usuario" pattern="[a-z A-ZÀ-ÿ\u00f1\u00d1]{1,150}" title="El nombre no puede incluir caracteres raros y no debe ser mayor a 150 caracteres" placeholder="Nombre Completo" class="register-ipt" id="nombre" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['nombre_usuario']."' "; } ?>>
                </div>
                <div class="admin-style">
                <label for="id_ciudad">Ciudad:</label>
                <select name="id_ciudad" id="id_ciudad" class="admin-style-new">
                <option disabled selected>Seleccione una ciudad:</option>
                <?php
                $sql = "SELECT id_ciudad, nombre_ciudad FROM ciudades;";
                $result = mysqli_query($conexion, $sql);
                while ($row = mysqli_fetch_assoc($result)) {
                    $selected = ($row['id_ciudad'] == $reg['id_ciudad']) ? "selected" : "";
                    echo "<option value='" . $row['id_ciudad'] . "' $selected>" . $row['nombre_ciudad'] . "</option>";}
                ?>
                </select>
                </div>
                <div class="admin-style">
                    <label for="correo">Correo</label>
                    <input type="email" name="correo" pattern="{1,100}" title="El correo no debe ser mayor a 100 caracteres" placeholder="Correo" class="register-ipt" id="correo" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['correo']."' "; } ?>>
                </div>
                <div class="admin-style">
                    <label for="usuario">Usuario</label>
                    <input type="text" name="usuario" pattern=".{1,15}" title="El nombre de usuario no debe ser mayor a 15 caracteres" placeholder="Nombre de Usuario" class="register-ipt" id="usuario" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['usuario']."' "; } ?>>
                </div>
                <div class="admin-style">
                    <label for="contraseña">Contraseña</label>
                    <input type="password" name="contraseña" placeholder="Contraseña" class="register-ipt" id="contraseña" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['contraseña']."' "; } ?>>
                </div>
                <div class="admin-style">
                    <label for="telefono">Teléfono</label>
                    <input type="tel" name="telefono" maxlength="10" placeholder="Teléfono" pattern="[0-9]{10,}" title="Ingrese un número de telefono valido" class="register-ipt" id="telefono" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['telefono']."' "; } ?>>
                </div>
                <div class="admin-style">
                <label for="id_rol">Rol:</label>
                <select name="id_rol" id="id_rol" class="admin-style-new">
                <option disabled selected>Seleccione un rol</option>
                <?php
                $roles = array(
                1 => "Administrador",
                2 => "Vendedor",
                3 => "Cliente");
                foreach ($roles as $id => $nombre) {
                    $selected = ($id == $reg['id_rol']) ? "selected" : "";
                    echo "<option value='$id' $selected>$nombre</option>";}
                ?>
                </select>
                </div>
                <?php 
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='clave' value='".$reg['id_usuarios']."' >" ;}
                ?>
                <span class="admin-btn-press">
               <!-- <input type="submit" name="Aceptar" class="button_top -red" value="Aceptar" onclick="return validarFormulario();">-->
                <button type="button" name="envform" id="envform" class="button_top -red" onclick="sendformadmin()">Aceptar</button>
                </span>
            </form>
        </div>
        <div class="view">
            <table>
                <tr class="tr-title">
                    <td>Clave Usuario</td>
                    <td>Nombre Completo</td>
                    <td>Ciudad</td>
                    <td>Correo</td>
                    <td>Usuario</td>
                    <td>Contraseña</td>
                    <td>Teléfono</td>
                    <td>Rol</td>
                  <!--  <td>Editar</td>-->
                    <td>Eliminar</td>
                </tr>
                <?php echo "Número de filas: " . $nfilas; 
                while($clientes=mysqli_fetch_array($resultado)) {?>

                <tr class="tr-info">
                    <td><?php echo $clientes['id_usuarios']?></td>
                    <td><?php echo $clientes['nombre_usuario']?></td>
                    <td><?php echo $clientes['nombre_ciudad']; ?></td>
                    <td><?php echo $clientes['correo']?></td>
                    <td><?php echo $clientes['usuario']?></td>
                    <td><?php echo $clientes['contraseña']?></td>
                    <td><?php echo $clientes['telefono']?></td>
                    <td><?php echo $clientes['nombre_rol']?></td>
                 <!--   <td><a onclick="edituser(<?php echo $clientes['id_usuarios']; ?>)">Editar</a></td>-->
                    <td><a onclick="deluser(<?php echo $clientes['id_usuarios']; ?>)">Eliminar</a></td>
                </tr>
                <?php }?>
            </table>
        </div>
    </div>
    