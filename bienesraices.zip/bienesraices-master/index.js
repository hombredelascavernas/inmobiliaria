import {recordData} from "./firebase.js";
import { deleteData } from "./firebase.js";


const formu  = document.getElementById("fb");

formu.addEventListener('submit',e =>{
    e.preventDefault();
    const name = formu['name'].value;
    const value2 = formu['value2'].value;

    //console.log(name,value2);
    recordData(name,value2);
});


formu['boton2'].addEventListener('submit',e =>{
    //e.preventDefault();
    const name = formu['name'].value;
   deleteData(name);
   
}
);

formu['boton3'].addEventListener('submit',e =>{
  //e.preventDefault();
  const value2= formu['value2'].value;
 updateData(value2);
 
}
);