<?php

    include 'conexion_be.php';

    $usu = $_POST['usuario'];
    $tipo = $_POST['tipo'];
    $mascota = $_POST['mascota'];
    $nombre_producto = $_POST['nombre_producto'];
    $cantidad = $_POST['cantidad'];
    $monto = $_POST['monto'];
    $fecha = $_POST['fecha'];
    $ubicacion = $_POST['ubicacion'];

    $query ="INSERT INTO dato_gasto(tipo,id_usuario, mascota, nombre_producto, cantidad, monto, fecha_compra, ubicacion) 
             VALUES('$tipo', '$usu', '$mascota', '$nombre_producto', '$cantidad', '$monto', '$fecha', '$ubicacion')";




    $eje = mysqli_query($conexion, $query);
    if($eje){
        echo '
        <script>
           alert("Gasto almacenado exitosamente");
           window.location = "../consulta_gasto.php";
        </script>
        ';
    }else{
        echo'
        <script>
           alert("Parece que hubo un error, los datos no se guardaron");
           window.location = "../formulario_gasto.php";
        </script>
        ';
    }

    mysqli_close($conexion);


?>

