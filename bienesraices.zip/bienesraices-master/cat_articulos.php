<?php
session_start();
    $usuario1=$_SESSION['usuario'];
    if(!isset($usuario1)){
        header("location:login.php");
    }
try{
include 'conexion.php';
// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta = "SELECT casas.*, usuarios.nombre_usuario, venta.nombre_venta, ciudades.nombre_ciudad
FROM casas
JOIN usuarios ON casas.id_usuarios = usuarios.id_usuarios
JOIN venta ON casas.id_venta = venta.id_venta
join ciudades on casas.id_ciudad=ciudades.id_ciudad";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);}catch(Exception $e){
    echo "error en la consulta: ". $e->getMessage();
}

//INSERTAR REGISTROS
if (isset($_GET['r'])) {
    $jsondata = $_GET['r'];
    $arr = json_decode($jsondata, true);
    $id_casa = $arr[0];
    $nombre_casa = $arr[1];
    $img = $arr[2];
    $imagen = $_FILES[$img]['tmp_name']; // Ruta temporal del archivo
    $imagen_destination = 'style/images/' . $img; // Cambia esta ruta
    move_uploaded_file($imagen, $imagen_destination);
        
    $precio = $arr[3];
    $habitaciones = $arr[4];
    $baños = $arr[5];
    $carro = $arr[6];
    $m2 = $arr[7];
    $ubicacion = $arr[8];
    $descripcion = $arr[9];
    $estatus= $arr[10];
    $id_usuarios = $arr[11];
    $id_venta = $arr[12];
    $id_ciudad= $arr[13];
    $insertar = "INSERT INTO casas (nombre_casa, imagen, precio, habitaciones, baños, carro, m2,ubicacion, descripcion, estatus, id_usuarios, id_venta,id_ciudad,id_casa) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";
    $stmt = mysqli_prepare($conexion, $insertar);
    mysqli_stmt_bind_param($stmt, "ssiiiiissiiiii", $nombre_casa, $imagen_destination, $precio, $habitaciones, $baños, $carro, $m2, $ubicacion, $descripcion, $estatus, $id_usuarios, $id_venta, $id_ciudad, $id_casa);
    $subio = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    if($subio){
        echo "<script>alert('casa registrada');</script>";
    }else{
        echo "<script>alert('error al registrar');</script>";
    }
}
/*if(isset($_REQUEST['id_casa']) && !isset($_REQUEST['clave'])){
    $id_casa = $_REQUEST['id_casa'];
    $nombre_casa = $_REQUEST['nombre_casa'];
    $imagen = $_FILES['imagen']['tmp_name']; // Ruta temporal del archivo
        if (empty($imagen)) {
            echo "<script>alert('Debes seleccionar una imagen');</script>";
        } else {
            // Procesar el archivo cargado aquí
            $imagen_name = $_FILES['imagen']['name'];
            $imagen_destination = 'style/images/' . $imagen_name; // Cambia esta ruta
            move_uploaded_file($imagen, $imagen_destination);}
    $precio = $_REQUEST['precio'];
    $habitaciones = $_REQUEST['habitaciones'];
    $baños = $_REQUEST['baños'];
    $carro = $_REQUEST['carro'];
    $m2 = $_REQUEST['m2'];
    $ubicacion = $_REQUEST['ubicacion'];
    $descripcion = $_REQUEST['descripcion'];
    $estatus= $_REQUEST['estatus'];
    $id_usuarios = $_REQUEST['id_usuarios'];
    $id_venta = $_REQUEST['id_venta'];
    $id_ciudad= $_REQUEST['id_ciudad'];
    $insertar = "INSERT INTO casas (nombre_casa, imagen, precio, habitaciones, baños, carro, m2,ubicacion, descripcion, estatus, id_usuarios, id_venta,id_ciudad,id_casa) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";
    $stmt = mysqli_prepare($conexion, $insertar);
    mysqli_stmt_bind_param($stmt, "ssiiiiissiiiii", $nombre_casa, $imagen_destination, $precio, $habitaciones, $baños, $carro, $m2, $ubicacion, $descripcion, $estatus, $id_usuarios, $id_venta, $id_ciudad, $id_casa);
    $subio = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    if ($subio) {
        echo "<script>alert('Casa registrada');</script>";
        header("Location: menu_admin.php"); // Redirigir a la página "menu_admin"
        exit; // Terminar el script para evitar que se siga ejecutando
    } else {
        echo "<script>alert('Error al insertar un registro, ==> recuerda rellenar todos los campos');</script>";
    }}*/
//ELIMINAR REGISTROS
if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from casas where id_casa=$eliminar");
    echo "<script>alert('Casa borrada');</script>";
    header("Location: menu_admin.php");
}
//EDITAR REGISTROS
//1.Consulta el registro que va editar
if(isset($_REQUEST['editar'])){
    $editar = $_REQUEST['editar'];
    $registros1 = mysqli_query($conexion, "SELECT * FROM casas WHERE id_casa=$editar");
    $reg = mysqli_fetch_array($registros1);
}
//2.Actualiza el Registro
if(isset($_REQUEST['clave'])){
    $id_casa = $_REQUEST['clave'];
    $jsondata = $_GET['k'];
    $arr = json_decode($jsondata, true);
    $nombre_casa = $arr[0];
    $img = $arr[1];
    $imagen = $_FILES[$img]['tmp_name']; // Ruta temporal del archivo
    $precio = $arr[2];
    $habitaciones = $arr[3];
    $baños = $arr[4];
    $carro = $arr[5];
    $m2 = $arr[6];
    $ubicacion = $arr[7];
    $descripcion = $arr[8];
    $estatus= $arr[9];
    $id_usuarios = $arr[10];
    $id_venta = $arr[11];
    $id_ciudad= $arr[12];

    if (!empty($imagen)) {
        // Si se ha subido una nueva imagen, procesarla y actualizar la ruta
        $imagen_destination = 'style/images/' . $img; // Cambia esta ruta
        move_uploaded_file($imagen, $imagen_destination);
    } else {
        // Si no se ha subido una nueva imagen, mantener la imagen anterior
        $imagen_destination = $arr[13];
    }
    $actualizar = "UPDATE casas SET nombre_casa=?,imagen=?, precio=?, habitaciones=?, baños=?, carro=?, m2=?, ubicacion=?, descripcion=?, estatus=?, id_usuarios=?, id_venta=?, id_ciudad=? 
                WHERE id_casa=?";
    $stmt = mysqli_prepare($conexion, $actualizar);
    mysqli_stmt_bind_param(
        $stmt,
        "ssiiiiissiiiii",
        $nombre_casa,
        $imagen_destination, // Usamos la ruta donde guardamos la imagen
        $precio,
        $habitaciones,
        $baños,
        $carro,
        $m2,
        $ubicacion,
        $descripcion,
        $estatus,
        $id_usuarios,
        $id_venta,
        $id_ciudad,
        $id_casa
    );
    $subio = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    if ($subio) {
        echo "<script>alert('Casa Actualizada');</script>";
        } 
    else {
        echo "<script>alert('Error al editar');</script>";}} 
/*if(isset($_REQUEST['clave'])){
    $id_casa = $_REQUEST['clave'];

    $nombre_casa = $_REQUEST['nombre_casa'];
    $imagen = $_FILES['imagen']['tmp_name']; // Ruta temporal del archivo
    $precio = $_REQUEST['precio'];
    $habitaciones = $_REQUEST['habitaciones'];
    $baños = $_REQUEST['baños'];
    $carro = $_REQUEST['carro'];
    $m2 = $_REQUEST['m2'];
    $ubicacion = $_REQUEST['ubicacion'];
    $descripcion = $_REQUEST['descripcion'];
    $estatus= $_REQUEST['estatus'];
    $id_usuarios = $_REQUEST['id_usuarios'];
    $id_venta = $_REQUEST['id_venta'];
    $id_ciudad= $_REQUEST['id_ciudad'];

    if (!empty($imagen)) {
        // Si se ha subido una nueva imagen, procesarla y actualizar la ruta
        $imagen_name = $_FILES['imagen']['name'];
        $imagen_destination = 'style/images/' . $imagen_name; // Cambia esta ruta
        move_uploaded_file($imagen, $imagen_destination);
    } else {
        // Si no se ha subido una nueva imagen, mantener la imagen anterior
        $imagen_destination = $_REQUEST['archivo_mod'];
    }
    $actualizar = "UPDATE casas SET nombre_casa=?,imagen=?, precio=?, habitaciones=?, baños=?, carro=?, m2=?, ubicacion=?, descripcion=?, estatus=?, id_usuarios=?, id_venta=?, id_ciudad=? 
                WHERE id_casa=?";
    $stmt = mysqli_prepare($conexion, $actualizar);
    mysqli_stmt_bind_param(
        $stmt,
        "ssiiiiissiiiii",
        $nombre_casa,
        $imagen_destination, // Usamos la ruta donde guardamos la imagen
        $precio,
        $habitaciones,
        $baños,
        $carro,
        $m2,
        $ubicacion,
        $descripcion,
        $estatus,
        $id_usuarios,
        $id_venta,
        $id_ciudad,
        $id_casa
    );
    $subio = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    if ($subio) {
        echo "<script>alert('Casa Actualizada');</script>";
        } 
    else {
        echo "<script>alert('Error al editar');</script>";}}*/ ?>

    <div class="admin-container">
        <div class="edite">
        <form name="update_form" id="userForm" class="admin-cli-edite" enctype="multipart/form-data">
                <div class="admin-style">
                    <label for="id_casa"></label>
                    <input type="hidden" id="idcasa" name="id_casa" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['id_casa']."'disabled "; } ?>placeholder="Clave" class="register-ipt" readonly><br>
                    <label for="nombre_casa">Titulo del articulo</label>
                    <input type="text" name="nombre_casa" pattern="[a-z A-ZÀ-ÿ\u00f1\u00d1]{1,150}" title="El nombre no puede incluir caracteres raros y no debe ser mayor a 150 caracteres" placeholder="Titulo" class="register-ipt" id="nombre_casa" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['nombre_casa']."' "; } ?>>
                </div>
                <div class="admin-style">
                    <label for="precio">Precio</label>
                    <input type="number" name="precio" pattern="{1,100}" title="No debe ser mayor a 100 caracteres" placeholder="Precio" class="register-ipt" id="precio" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['precio']."' "; } ?>>
                    <label for="habitaciones">Habitaciones</label>
                    <input type="number" name="habitaciones" pattern="{1,2}"  placeholder="Habitaciones" class="register-ipt" id="habitaciones" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['habitaciones']."' "; } ?>>
                </div>
                <div class="admin-style">
                    <label for="baños">Baños</label>
                    <input type="number" name="baños" pattern=".{1,2}"  placeholder="Baños de la propiedad" class="register-ipt" id="baños" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['baños']."' "; } ?>>
                    <label for="carro">Capacidad del garaje</label>
                    <input type="number" name="carro" placeholder="Gareges de la propiedad" class="register-ipt" id="carro" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['carro']."' "; } ?>>
                 </div>
                <div class="admin-style">
                    <label for="descripcion">Descripción</label>
                    <textarea name="descripcion" id="descripcion" cols="29" rows="3" class="admin-area"><?php if(isset($_REQUEST['editar'])) {echo $reg['descripcion']; } ?></textarea>
                    <label for="m2">Metros Cuadrados</label>
                    <input type="number" name="m2"  placeholder="Metros Cuadrados del Terreno" class="register-ipt" id="m2" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['m2']."' "; } ?>></div>
                <div class="admin-style">
                    <label for="estatus">Estatus</label>
                    <select name="estatus" id="estatus" class="admin-style-new">
                        <option disabled selected> Selecciona un estatus</option>
                        <option value="0" <?php if(isset($_REQUEST['editar']) && $reg['estatus'] == 0) { echo "selected"; } ?>>Disponible</option>
                        <option value="1" <?php if(isset($_REQUEST['editar']) && $reg['estatus'] == 1) { echo "selected"; } ?>>Ocupado</option>
                    </select>
                    <label for="ubicacion">Localizacion de la propiedad</label>
                    <textarea name="ubicacion" id="ubicacion" cols="29" rows="3" class="admin-area"><?php if(isset($_REQUEST['editar'])) {echo $reg['ubicacion']; } ?></textarea>
                </div>

                <!--             <div class="admin-style">
                    <span class="admin-btn-press">
                        <label for="imagen" class="button_top -purple">Selecciona una Imágen</label>
                    </span>
                    <input type="file" name="imagen" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['imagen']."' "; }?> accept="images/*" id="imagen">
                </div> -->
                <div class="admin-style">
                <span class="admin-btn-press">
                <label for="imagen" class="button_top -purple">Selecciona una Imágen</label>
                   <input type="file" name="imagen" accept="images/*" id="imagen">
                   </span>
                </div>
                <div class="admin-style-new">
                <select name="id_usuarios" id="id_usuarios" class="admin-style-new">
                <option disabled selected>Seleccione un usuario:</option>
                <?php
                $sql = "SELECT id_usuarios, nombre_usuario FROM usuarios;";
                $result = mysqli_query($conexion, $sql);
                while ($row = mysqli_fetch_assoc($result)) {
                    $selected = ($row['id_usuarios'] == $reg['id_usuarios']) ? "selected" : "";
                    echo "<option value='" . $row['id_usuarios'] . "' $selected>" . $row['nombre_usuario'] . "</option>";}
                ?>
                </select>
                <select name="id_venta" id="id_venta" class="admin-style-new">
                    <option disabled selected>Venta/Renta</option>
                    <option value="1" <?php if(isset($_REQUEST['editar']) && $reg['id_venta'] == 1) { echo "selected"; } ?>>Venta</option>
                    <option value="2" <?php if(isset($_REQUEST['editar']) && $reg['id_venta'] == 2) { echo "selected"; } ?>>Renta</option>
                </select><br>
                <select name="id_ciudad" id="id_ciudad" class="admin-style-new">
                <option disabled selected>Seleccione una ciudad:</option>
                <?php
                $sql = "SELECT id_ciudad, nombre_ciudad FROM ciudades;";
                $result = mysqli_query($conexion, $sql);
                while ($row = mysqli_fetch_assoc($result)) {
                    $selected = ($row['id_ciudad'] == $reg['id_ciudad']) ? "selected" : "";
                    echo "<option value='" . $row['id_ciudad'] . "' $selected>" . $row['nombre_ciudad'] . "</option>";}
                ?>
                </select>
                </div>
                <?php 
                if(isset($_REQUEST['editar'])) {
                    echo "<input type='hidden' name='clave' value='".$reg['id_casa']."' >";
                   echo "<input type='hidden' id='archivo_mod' name='archivo_mod' value='".(isset($reg['imagen']) ? $reg['imagen'] : '')."'>";
                  }?>
                <span class="admin-btn-press"><?php
                    if (isset($_GET['editar'])){
                        ?>
                <button type="button" name="updateform" id="userformedit" class="button_top -red" onclick="catartformedit(<?php echo $reg['id_casa']; ?>)">Aceptar</button>
                        
                        <?php
                    }else{
                ?>
                <button type="button" name="updateform" id="userform" class="button_top -red" onclick="catartform()">Aceptar</button>
                <?php
                    }
                ?>
                </span>
            </form>
        </div>

        <div class="view">
            <table>
                <tr class="tr-title">
                    <td>Clave Casa</td>
                    <td>Titulo del articulo</td>
                    <td>Imagen</td>
                    <td>Precio</td>
                    <td>Habitaciones</td>
                    <td>Baños</td>
                    <td>Garaje (capacidad)</td>
                    <td>m2</td>
                    <td>Ubicacion</td>
                    <td>Descripción</td>
                    <td>Estatus</td>
                    <td>Usuario</td>
                    <td>Venta/Renta</td>
                    <td>Ciudad</td>
                 <!--   <td>Editar</td>-->
                    <td>Eliminar</td>
                </tr>
                <?php echo "Número de filas: ". $nfilas;
                 while($casas=mysqli_fetch_array($resultado)) {?>
                <tr class="tr-info">
                    <td><?php echo $casas['id_casa']?></td>
                    <td><?php echo $casas['nombre_casa']?></td>
                    <td><img src="<?php echo $casas['imagen']?>" alt="<?php echo $casas['imagen']?>"></td>
                    <td><?php echo $casas['precio']?></td>
                    <td><?php echo $casas['habitaciones']?></td>
                    <td><?php echo $casas['baños']?></td>
                    <td><?php echo $casas['carro']?></td>
                    <td><?php echo $casas['m2']?></td>
                    <td><?php echo $casas['ubicacion']?></td>
                    <td><?php echo $casas['descripcion']?></td>
                    <td><?php  if ($casas['estatus']==0){echo "Disponible";}else{echo"Ocupado";}?></td>
                    <td><?php echo $casas['nombre_usuario']?></td>
                    <td><?php echo $casas['nombre_venta']?></td>
                    <td><?php echo $casas['nombre_ciudad']?></td>
                   <td><a onclick="editart(<?php echo $casas['id_casa']; ?>)">Editar</a></td>
                    <td><a onclick="delart(<?php echo $casas['id_casa']; ?>)">Eliminar</a></td>
                </tr>
                <?php }?>
            </table>
        </div>
    </div><!--
</body>
</html>
