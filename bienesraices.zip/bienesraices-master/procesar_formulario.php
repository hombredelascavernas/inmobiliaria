<?php
include 'conexion.php'; // Incluir el archivo de conexión a la base de datos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipoDatos = $_POST['tipo_datos'];
    $nombre = $_POST['nombre'];
$x="12";

    // Realizar la inserción en la tabla correspondiente
    include 'conexion.php'; // Incluir el archivo de conexión a la base de datos

    if ($tipoDatos === 'ciudad') {
        // Insertar en la tabla "ciudades"
        $insertar = "INSERT INTO ciudades (id_ciudad,nombre_ciudad) VALUES (?,?)";
       $stmt= mysqli_prepare($conexion, $insertar);
mysqli_stmt_bind_param($stmt,"is",$x,$nombre);
$subio = mysqli_stmt_execute($stmt);

if ($subio) {
    echo "<script>alert('Casa registrada');</script>";
    echo "<script>window.location='añadir_ciudad.php';</script>";} else {
    echo "<script>alert('Error al insertar un registro, ==> recuerda rellenar todos los campos');</script>"; 
}}}?>