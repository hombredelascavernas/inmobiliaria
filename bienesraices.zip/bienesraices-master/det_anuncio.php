<?php

include 'conexion.php';

$id_casa=$_GET['id_casa'];

$consulta="select * from casas where id_casa=$id_casa";
$resultado=mysqli_query($conexion,$consulta);
$casas=mysqli_fetch_assoc($resultado);

$id_usuarios=$casas['id_usuarios'];
$id_ventas=$casas['id_venta'];

$consultas="select * from usuarios where id_usuarios=$id_usuarios";
$resultado2=mysqli_query($conexion,$consultas);
$usuarios=mysqli_fetch_assoc($resultado2);

?>

<?php

$cat_categoria="SELECT * FROM venta where id_venta=$id_ventas";
$resultado = mysqli_query($conexion, $cat_categoria);
$categoria=mysqli_fetch_array($resultado);
?>
<!DOCTYPE html>
<html lang="en">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="http://localhost/php/bienesraices-master/js/jsfiles.js"></script>
    <head>
        <meta name="encoding" charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bienes raíces</title>
        <meta name="autor" content="Paula Farias">
        <meta name="description" content="Venta de casas y departamentos exclusivos de lujo.">
        <link rel="shorcut icon" href="style/images/logo.svg" />
    
        <!-- GOOGLE FONTS -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito&display=swap" rel="stylesheet">
    
        <!-- FONT AWESOME -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css"
            integrity="sha512-q3eWabyZPc1XTCmF+8/LuE1ozpg5xxn7iO89yfSOd5/oKvyqLngoNGsx8jq92Y8eXJ/IRxQbEC+FGSYxtk2oiw=="
            crossorigin="anonymous" />
             
        <!-- CSS -->
        <link rel="stylesheet" href="style/detalle.css">
        
    
    
    </head>
    
<body>
    <header>
        <!-- menu -->
        <div class="navbar">
            <img class="logo" src="style/images/logo.svg" alt="logo bienes raices">
            <nav class="nav_links">
                    <a href="index.php">Inicio</a>
                    <a href="nosotros.php">Nosotros</a>
                    <a href="anuncios.php">Anuncios</a>
                    <a href="contacto.php">Contacto</a>
                    <a href="login.php">Iniciar Sesion</a>                
            </nav>
        </div>
        
        <!-- text -->
    </header>
    <section id="casas_en_venta">


  <div class="carousel-inner" style="width: 100%; height: 50vh;">
    <div class="carousel-item active">
      <img src="<?php echo $casas ['imagen'] ?>" class="d-block w-100" alt="..." style="width: 100%; height: 50vh;">
    </div>
  </div>
  </section>

<div class="cuerpo">
  <div class="det-info">
  <h1>Detalles Generales De la propiedad</h1>
    <div class="det-gen">
        <h2><?php echo $casas ['nombre_casa'] ?></h2>
        <h2 class="precio">$<?php echo $casas ['precio'] ?></h2>
    </div>
    <div class="det-icon">
        <h2 class="tit">Detalles generales</h2><br>
        <img src="style/images/icono_wc.svg" alt=""> <span>Baños: <?php echo $casas['baños']; ?></span>
        <img src="style/images/icono_estacionamiento.svg" alt="">Estacionamiento: <span><?php echo $casas['carro']; ?></span>
        <img src="style/images/icono_dormitorio.svg" alt=""> <span>Habitaciones: <?php echo $casas['habitaciones']; ?></span><br><br>
        <img src="style/images/m2.png" alt="" style="width: 35px; height: 35px;"> <span>Terreno: <?php echo $casas['m2']; ?>m2</span>
    </div>
    <div class="det-contenido">
      <h2 class="tit">Esta propiedad esta en <?php echo $categoria['nombre_venta'] ?></h2>
      <h2 class="ubi">Ubicada en <?php echo $casas ['ubicacion'] ?></h2><br>
      <h2 class="tit">Descripción</h2><br>
      <h2 class='des'><?php echo $casas ['descripcion'] ?></h2>
    </div>
  </div>

  <div class="det-mensaje" id="module1"><!--el ajax modifica todo lo que esta dentro de este div sin necesidad de recargar o redireccionar la pagina-->
    <h1>Mensaje</h1>
    <div class="det"> 
        <h2 class="tit" style="float: left;">Telefono del propietario:</h2>
        <h2 style="font-size: 20px; color: orange;float: right;"><?php echo $usuarios ['telefono'] ?></h2><br>
        <h2 class="tit"style="float: left;">Nombre del propietario:    </h2>
        <h2 style="font-size: 20px; color: orange;float: right;"><?php echo $usuarios ['nombre_usuario'] ?></h2>
    </div><br><br>
    <!--como se usara ajax el formulario ya no tendra accion ni metodo definido pues de eso se encarga el ajax-->
    <form>
            <!--
              cambie las id's de los campos para trabajarlos en el js
              nombre = inputEmail3
              email = inputEmail3
              telefono = inputEmail3
              mensaje = exampleFormControlTextarea1
            -->
            <div class="row mb-3">
              <h2 class="tit">Nombre</h2>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="nombre"  name="nombre" require>
              </div>
            </div>
    
            <div class="row mb-3">
                <h2 class="tit">Email</h2>
                <div class="col-sm-10">
                  <input type="email" class="form-control" id="email"  name="email" require>
                </div>
            </div>
    
            <div class="row mb-3">
                <h2 class="tit">Telefono</h2>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="celular" name="celular" maxlength="10" require>
                </div>
              </div>
    
              <div class="mb-3">
                <label for="mensajetxt" class="form-label">Mensaje</label>
                <textarea class="form-control" id="mensajetxt" rows="3" name="mensaje" require></textarea>
              </div>
          
              <!--creamos y pasamos un campo oculto que contiene la clave del empleado
                  agregre 2 id's al campo id_casa y id_usuario para trabajarlos en js
            -->
              <input type="hidden" id="idcasa" name="id_casa" value="<?php echo $casas['id_casa']?>">
              <input type="hidden" id="iduser" name="id_usuarios" value="<?php echo $usuarios['id_usuarios']?>">
              <!--cambie el inpput por un button para trabajar el evento on click que usa la funcion de javascript-->
              <input type="button" name="envform" id="mensaje" value="Enviar" onclick="sendmessage()">
              
              <!--<input type="submit" name="enviar" vlaue="Enviar">-->
      </form>
          </div>
  </div>

</div>
            
        
        
        
    
   

</body>
</html>