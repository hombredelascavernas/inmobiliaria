<?php
include 'conexion.php';
$contacto="select * from contacto";
$resultado1 = mysqli_query($conexion, $contacto);


// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta="select * from contacto";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);

//INSERTAR REGISTROS
if (isset($_GET['r'])){
  $jsonData = $_GET['r'];
    $dataArray = json_decode($jsonData, true);
    $nombre=$dataArray[0];
    $email=$dataArray[1];
    $mensaje=$dataArray[2];
    $telefono=$dataArray[3];

    $insertar="insert into contacto (nombre, email, telefono, mensaje) VALUES ('$nombre','$email','$telefono','$mensaje')";
    $eje = mysqli_query($conexion, $insertar);

    if($eje){
      $response = array("status" => "success", "message" => "Entrada registrada con exito.");
    http_response_code(200);

    echo json_encode($response);
    }else{
      $response = array("status" => "failed", "message" => "error al registrar entrada.");
    http_response_code(500);

    echo json_encode($response);
    }
}
/*if(isset($_POST['nombre'])){
    $nombre=$_POST['nombre'];
    $email=$_POST['email'];
    $mensaje=$_POST['mensaje'];
    $telefono=$_POST['telefono'];

    $insertar="insert into contacto (nombre, email, telefono, mensaje) VALUES ('$nombre','$email','$telefono','$mensaje')";
    if(!$insertar){
      echo "ha ocurrido un error: ". mysqli_error($conexion);
    }
    if (mysqli_query($conexion,$insertar)){  
        echo "<script>alert('Comentario Enviado');</script>";
        echo"<script>window.location='contacto.php';</script>";
    }
    else{
        echo"<script>alert('Error');</script>";
    }
}*/
?>

<!DOCTYPE html>
<html lang="en">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="http://localhost/php/bienesraices-master/js/jsfiles.js"></script>

<head>
    <meta name="encoding" charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienes raíces</title>
    <meta name="autor" content="Paula Farias">
    <meta name="description" content="Venta de casas y departamentos exclusivos de lujo.">
    <link rel="shorcut icon" href="style/images/logo.svg" />

    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito&display=swap" rel="stylesheet">

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css"
        integrity="sha512-q3eWabyZPc1XTCmF+8/LuE1ozpg5xxn7iO89yfSOd5/oKvyqLngoNGsx8jq92Y8eXJ/IRxQbEC+FGSYxtk2oiw=="
        crossorigin="anonymous" />
         
    <!-- CSS -->
    <link rel="stylesheet" href="style/nosotros.css">
    


</head>

<body>
    <!------- HEADER ------->
    <header>
        <!-- menu -->
        <div class="navbar">
            <img class="logo" src="style/images/logo.svg" alt="logo bienes raices">
            <nav class="nav_links">
                    <a href="index.php">Inicio</a>
                    <a href="nosotros.php">Nosotros</a>
                    <a href="anuncios.php">Anuncios</a>
                    <a href="contacto.php">Contacto</a>
                    <a href="consejos_usuarios.html">Consejos Millonarios</a>
                    <a href="login.php">Iniciar Sesion</a>                 
            </nav>
        </div>
        
        <!-- text -->
    </header>

    <section id="conocenos_nosotros">

        <h2>ANUNCIATE CON NOSOTROS</h2><br>


             <div class="card" style="width: 750px; left: 25%; bottom: 20px;">
                <img src="style/images/anuncio1.jpg" class="card-img-top" alt="...">
                    <div class="col-md-8">
                    
                    </div>
                </div>
              </div>

        </div>
    </section>

   

    <!------- MAS SOBRE NOSOTROS ------->
    <section id="contacto">
<!-- -----------------------------------------------------------------------------------------> 
        <h2 style="margin-bottom: 100px;">Llena el Formulario del Contacto</h2>
        <h4>Informacion personal</h4>

<!---------------------------FORMULARIO CONTACTO
-->
        <div id="module3">
        <form style=" margin-left: 400px; width: 100%;">
            <div class="row mb-3" style=" 
            padding: 20px;
            width: 40%;
           ">
              <label for="nombre" class="col-sm-2 col-form-label">Nombre</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="nombre"  name="nombre">
              </div>
            </div>
    
            <div class="row mb-3" style="padding: 20px;
            width: 40%;">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" id="email"  name="email">
                </div>
            </div>
    
            <div class="row mb-3" style="padding: 20px;
            width: 40%;">
                <label for="tel" class="col-sm-2 col-form-label">Telefono</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="tel" name="telefono" maxlength="10">
                </div>
              </div>
    
              <div class="mb-3" style="padding: 20px;
              width: 40%;">
                <label for="messagge" class="form-label">Mensaje</label>
                <textarea class="form-control" id="messagge" rows="3" name="mensaje"></textarea>
              </div>
           <br> </div>
           <button type="button" id="envform" name="envform" onclick="sendinfcont()">Enviar</button>
          </form>
</div>
<!------------------------------------------------------------------------------------------------------------------------------------->


    </section>

    <!------- CASAS Y DEPAS EN VENTA ------->



    <!------- FOOTER ------->
    <footer>
        <div>
            <a href="" >Instagram</a>
            <a href="">Facebook</a>
            <a href="">(993)-300-800</a>
            <a href="">Contacto</a>
        </div>
        <div>
            <p>Todos los derechos reservados ©</p>
        </div>
    </footer>
</body>