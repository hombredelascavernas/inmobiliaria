    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Formulario y Lista de Consejos</title>        <link rel="stylesheet" href="style/mainadmin.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
        <script src="http://localhost/php/bienesraices-master/js/jsfiles.js"></script>
        <style>
  
  body {
      font-family: 'Arial', sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: row;
      align-items: center;
      text-align: center;
  }
  aside{
            width: 20%; /* Ajusta el ancho del aside según tus preferencias */
            background-color: #333; /* Agrega el color de fondo que desees */
            padding: 20px;
            box-sizing: border-box;
            color: #fff;
  }

  form{
      background-color: #808080;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      margin-left: 20px;
      width: 50%;
  }

  h1 {
      color: #fff;
  }

  label {
      display: block;
      margin-bottom: 8px;
      color: #555;
  }

  input,
  textarea {
      width: 100%;
      padding: 8px;
      margin-bottom: 16px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
  }

  button {
      background-color: #25a3a3;
      color: #fff;
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
  }

  button:hover {
      background-color: #777c78;
  }

  table {
      border-collapse: collapse;
      width: 50%;
      margin-left: 20px;
  }

  th, td {
      border: 1px solid #808080;
      padding: 8px;
      text-align: left;
  }

  th {
      background-color: #4ca3c5;
      color: white;
  }

  .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.4);
  }

  .modal-content {
      background-color: #fefefe;
      margin: 10% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 80%;
  }

  .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
  }

  .close:hover,
  .close:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
  }
</style>
    </head>
    <body class="admin-body">
        <aside class="admin-aside">
            <div class="admin-first">  
                <h1>Bienvenido 
                    <?php echo $usuario1 ?> 
                </h1> 
                <img src="style/images/adminpro.png" alt="usuario" class="admin-pic">
                <div class="admin-btn">
                    <button class="admin-btn-press">
                        <a href="cerrar.php" class="button_top -orange">Cerrar Sesión</a>
                    </button>
                </div>
            </div>  
            <div class="cat-div"> 
            
                <a onclick="mainmenu()">
                    <img src="style/images/perfil.png" alt="Face" class="fku">
                    <p>Usuarios</p>
                </a>
                <a onclick="catart()">
                    <img src="style/images/articulos.png" alt="Pets" class="fku">
                    <p>Articulos</p>
                </a>
                <a onclick="messagges()">
                    <img src="style/images/correo-electronico.png" alt="Shipping" class="fku">
                    <p>Mensajes</p>
                </a>
                <a onclick="adcity()">
                    <img src="style/images/articulos.png" alt="Pets" class="fku">
                    <p>Añadir Ciudad</p>
            </a>
                <a href="consejos.php">
                 <img src= "style/images/articulos.png" alt = "Pets" class="fku">
                    <p>consejos<p>
                    </a>
</div>
</aside>
<div class="admin-container" id="module4">
        <form id="consejoForm">
        <h1>Formulario de Consejos</h1>
        <input type="text" id="nombre" placeholder="Nombre del consejo" required><br>

        <textarea id="consejo" placeholder="Escribe el consejo" required></textarea><br>

        <button type="button" onclick="window.agregarConsejo()">Agregar Consejo</button>
    </form>

    <h1>Lista de Consejos</h1>
    <table id="consejosTable">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Consejo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody id="consejosBody">
           
        </tbody>
    </table>

    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Editar Consejo</h2>
            <label for="editNombre">Nombre:</label>
            <input type="text" id="editNombre"><br>
            <label for="editConsejo">Consejo:</label>
            <textarea id="editConsejo"></textarea><br>
            <button type="button" onclick="guardarEdicion()">Guardar Edición</button>
        </div>
    </div>

    <script type="module">
        import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-app.js';
        import { getDatabase, ref, push, set, onValue, remove } from 'https://www.gstatic.com/firebasejs/9.6.0/firebase-database.js';

        const firebaseConfig = {
            apiKey: "AIzaSyD8jQTCWqLCA2C2MAtZEKC5GEpT3Nlp5Ak",
            authDomain: "prueba-ccf57.firebaseapp.com",
            databaseURL: "https://prueba-ccf57-default-rtdb.firebaseio.com",
            projectId: "prueba-ccf57",
            storageBucket: "prueba-ccf57.appspot.com",
            messagingSenderId: "215770791149",
            appId: "1:215770791149:web:64e40506bd79a6f4b8a0e4"
        };

        const app = initializeApp(firebaseConfig);
        const database = getDatabase(app);

        window.agregarConsejo = function() {
            const nombre = document.getElementById('nombre').value;
            const consejo = document.getElementById('consejo').value;
         
            if (nombre && consejo) {
                const consejosRef = ref(database, 'consejos');
                const nuevoConsejoRef = push(consejosRef);
                set(nuevoConsejoRef, {
                    nombre: nombre,
                    consejo: consejo
                });
                document.getElementById('nombre').value = '';
                document.getElementById('consejo').value = '';

                alert('Consejo agregado exitosamente');
            } else {
                alert('Por favor, completa todos los campos');
            }
        };
        document.addEventListener('DOMContentLoaded', () => {
            const tableBody = document.getElementById('consejosBody');
            const consejosRef = ref(database, 'consejos');
            onValue(consejosRef, snapshot => {
                tableBody.innerHTML = '';
                snapshot.forEach(childSnapshot => {
                    const consejo = childSnapshot.val();
                    const newRow = tableBody.insertRow();
                    newRow.innerHTML = `
                        <td>${consejo.nombre}</td>
                        <td>${consejo.consejo}</td>
                        <td>
                            <button onclick="editarConsejo('${childSnapshot.key}', '${consejo.nombre}', '${consejo.consejo}')">Editar</button>
                            <button onclick="eliminarConsejo('${childSnapshot.key}')">Eliminar</button>
                        </td>
                    `;
                });
            });
        });
        let editKey = null;
        window.eliminarConsejo = function(consejoKey) {
            const confirmacion = confirm('¿Seguro que quieres eliminar este consejo?');

            if (confirmacion) {
                const consejoRef = ref(database, `consejos/${consejoKey}`);
                remove(consejoRef);

                alert('Consejo eliminado exitosamente');
            }
        }

        window.editarConsejo = function(key, nombre, consejo) {
            editKey = key;
            document.getElementById('editNombre').value = nombre;
            document.getElementById('editConsejo').value = consejo;
            showModal();
        };
        window.guardarEdicion = function() {
            const nuevoNombre = document.getElementById('editNombre').value;
            const nuevoConsejo = document.getElementById('editConsejo').value;
            const consejoRef = ref(database, `consejos/${editKey}`);
            set(consejoRef, {
                nombre: nuevoNombre,
                consejo: nuevoConsejo
            });
            closeModal();
        };

        function showModal() {
            const modal = document.getElementById('editModal');
            modal.style.display = 'block';
        }
        function closeModal() {
            const modal = document.getElementById('editModal');
            modal.style.display = 'none';
        }
    </script>
     </div>
</body>
</html>