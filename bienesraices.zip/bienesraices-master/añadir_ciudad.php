<?php
session_start();
$usuario1 = $_SESSION['usuario'];
if (!isset($usuario1)) {
    header("location:login.php");
    exit(); // Se recomienda agregar un exit() después de una redirección para detener la ejecución del resto del código
}
?>
<!--<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/mainadmin.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
</head>
<body class="admin-body">
    <aside class="admin-aside">
        <div class="admin-first">  
            <h1>Bienvenido 
                <?php echo $usuario1 ?> 
            </h1> 
            <img src="style/images/adminpro.png" alt="usuario" class="admin-pic">
            <div class="admin-btn">
                <button class="admin-btn-press">
                    <a href="cerrar.php" class="button_top -orange">Cerrar Sesión</a>
                </button>
            </div>
        </div>  
        <div class="cat-div">
            <a href="menu_admin.php">
                <img src="style/images/perfil.png" alt="Face" class="fku">
                <p>Usuarios</p>
            </a>
            <a href="cat_articulos.php">
                <img src="style/images/articulos.png" alt="Pets" class="fku">
                <p>Articulos</p>
            </a>
            <a href="mensajes.php">
                <img src="style/images/correo-electronico.png" alt="Shipping" class="fku">
                <p>Mensajes</p>
            </a>
            <a href="añadir_ciudad.php">
                <img src="style/images/articulos.png" alt="Pets" class="fku">
                <p>Añadir Ciudad</p>
            </a>
        </div>
    </aside>
--><div class="admin-container">
        <form action="procesar_formulario.php" method="POST">
            <h1>Selecciona una opción:</h1>
           <!-- Opción Ciudad -->              
            <label >Ciudad</label>
           <input type="hidden" name="tipo_datos" value="ciudad" id="radio_ciudad">

            <!-- Opción Rol -->
            <h2>Datos:</h2>
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre" required>
            <br><br>
            <input type="submit" value="Guardar">
        </form>
    </div><!--
</body>
</html>
